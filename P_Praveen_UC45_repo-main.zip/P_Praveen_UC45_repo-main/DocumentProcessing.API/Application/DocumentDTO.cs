﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application
{
    public class DocumentDTO
    {
        public Guid DocumentId { get; set; }
        public string FileName { get; set; }
        public long FileSize { get; set; }
        public string MimeType { get; set; }
        public string UploadedBy { get; set; }
        public DateTime UploadedAt { get; set; }
        public DocumentStatusDTO Status { get; set; }
        public string ProcessingResults { get; set; } // JSON string
        public string StorageLocation { get; set; }
        public string EncryptionKey { get; set; }
    }
}
