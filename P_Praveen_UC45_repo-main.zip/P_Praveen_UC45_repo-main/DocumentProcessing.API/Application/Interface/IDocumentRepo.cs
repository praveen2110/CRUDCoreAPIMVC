﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Application.Interface
{
    public interface IDocumentRepo
    {
        Task<Domain.Document> GetByIdAsync(Guid id);
        Task AddAsync(Domain.Document document);
        Task UpdateAsync(Domain.Document document);
        Task<IEnumerable<Domain.Document>> GetPendingDocumentsAsync();
    }
}
