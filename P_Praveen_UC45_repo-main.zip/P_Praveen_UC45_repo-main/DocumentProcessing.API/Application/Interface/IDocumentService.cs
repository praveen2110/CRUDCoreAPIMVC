﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Interface
{
    public interface IDocumentService
    {
        Task<Guid> UploadAsync(IFormFile file, string notificationEmail, string uploadedBy);
        Task<(DocumentStatusDTO status, string result, string failureReason)> GetStatusAsync(Guid id);
        Task<(byte[] fileContent, string contentType, string fileName)> DownloadAsync(Guid id);
        Task ProcessPendingDocumentsAsync();
        Task<DocumentDTO> GetDocumentAsync(Guid id);
    }
}
