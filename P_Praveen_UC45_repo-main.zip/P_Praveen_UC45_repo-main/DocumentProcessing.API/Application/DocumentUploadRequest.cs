﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application
{
    public class DocumentUploadRequest
    {
        public IFormFile File { get; set; }
        public string UploadedBy { get; set; }
        public string NotificationEmail { get; set; }
    }
}
