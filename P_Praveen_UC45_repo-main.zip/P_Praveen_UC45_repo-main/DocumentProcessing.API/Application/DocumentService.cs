﻿using Application.Interface;
using Domain;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Application
{
    public class DocumentService : IDocumentService
    {
        private readonly IDocumentRepo _repository;
        //private readonly INotificationService _notificationService;

        public DocumentService(IDocumentRepo repository)
        {
            _repository = repository;
            // _notificationService = notificationService;
        }

        public async Task<Guid> UploadAsync(IFormFile file, string notificationEmail, string uploadedBy)
        {
            var id = Guid.NewGuid();
            var filePath = Path.Combine("SecureStorage", id.ToString());
            Directory.CreateDirectory("SecureStorage");
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var document = new Document
            {
                DocumentId = id,
                FileName = file.FileName,
                FileSize = file.Length,
                MimeType = file.ContentType,
                UploadedBy = uploadedBy,
                UploadedAt = DateTime.UtcNow,
                Status = DocumentStatus.Uploaded,
                StorageLocation = filePath,
                EncryptionKey = "Secure_File", // Replace with actual key generation
                ProcessingResults = DocumentStatusDTO.Processed.ToString()
            };

            await _repository.AddAsync(document);
            // Optionally: enqueue for async processing

            return id;
        }

        public async Task<DocumentDTO> GetDocumentAsync(Guid id)
        {
            var doc = await _repository.GetByIdAsync(id);
            if (doc == null) return null;

            return new DocumentDTO
            {
                DocumentId = doc.DocumentId,
                FileName = doc.FileName,
                FileSize = doc.FileSize,
                MimeType = doc.MimeType,
                UploadedBy = doc.UploadedBy,
                UploadedAt = doc.UploadedAt,
                Status = (DocumentStatusDTO)doc.Status,
                ProcessingResults = doc.ProcessingResults,
                StorageLocation = doc.StorageLocation,
                EncryptionKey = doc.EncryptionKey
            };
        }

        public async Task<(DocumentStatusDTO status, string result, string failureReason)> GetStatusAsync(Guid id)
        {
            var doc = await _repository.GetByIdAsync(id);
            if (doc == null)
                return (DocumentStatusDTO.Failed, null, "Document not found");

            return ((DocumentStatusDTO)doc.Status, doc.ProcessingResults, null);
        }

        public async Task<(byte[] fileContent, string contentType, string fileName)> DownloadAsync(Guid id)
        {
            var doc = await _repository.GetByIdAsync(id);
            if (doc == null)
                throw new FileNotFoundException("Document not found.");

            if (doc.ProcessingResults != DocumentStatus.Processed.ToString())
                throw new InvalidOperationException("Document not processed yet.");

            var fileContent = await File.ReadAllBytesAsync(doc.StorageLocation);
            return (fileContent, doc.MimeType, doc.FileName);
        }

        public async Task ProcessPendingDocumentsAsync()
        {
            var pendingDocs = await _repository.GetPendingDocumentsAsync();
            foreach (var doc in pendingDocs)
            {
                try
                {
                    doc.Status = DocumentStatus.Processing;
                    await _repository.UpdateAsync(doc);

                    // Simulate processing
                    await Task.Delay(1000);

                    // Example: set processing results as JSON
                    doc.ProcessingResults = "{\"message\": \"Processed successfully\"}";
                    doc.Status = DocumentStatus.Processed;
                    await _repository.UpdateAsync(doc);

                    // Optionally notify user
                    // await _notificationService.NotifyAsync(doc.NotificationEmail, $"Document {doc.FileName} processed successfully.");
                }
                catch (Exception ex)
                {
                    doc.Status = DocumentStatus.Failed;
                    doc.ProcessingResults = $"{{\"error\": \"{ex.Message}\"}}";
                    await _repository.UpdateAsync(doc);

                    // Optionally notify user
                    // await _notificationService.NotifyAsync(doc.NotificationEmail, $"Document {doc.FileName} failed: {ex.Message}");
                }
            }
        }
    }
}