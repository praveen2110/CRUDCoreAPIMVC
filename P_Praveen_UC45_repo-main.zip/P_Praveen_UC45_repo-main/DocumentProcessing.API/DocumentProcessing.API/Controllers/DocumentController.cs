﻿using Application;
using Application.Interface;
using Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DocumentProcessing.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DocumentController : ControllerBase
    {
        private readonly IDocumentService _documentService;

        public DocumentController(IDocumentService documentService)
        {
            _documentService = documentService;
        }

        // POST: api/document/upload
        [HttpPost("upload")]
        public async Task<IActionResult> Upload([FromForm] DocumentUploadRequest request)
        {
            if (request.File == null || request.File.Length == 0)
                return BadRequest("No file uploaded.");

            var documentId = await _documentService.UploadAsync(request.File, request.NotificationEmail, request.UploadedBy);
            return Ok(new { documentId });
        }

        // GET: api/document/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetDocument(Guid id)
        {
            var document = await _documentService.GetDocumentAsync(id);
            if (document == null)
                return NotFound();

            return Ok(document);
        }

        // GET: api/document/{id}/status
        [HttpGet("{id}/status")]
        public async Task<IActionResult> GetStatus(Guid id)
        {
            var (status, result, failureReason) = await _documentService.GetStatusAsync(id);
            return Ok(new { status, result, failureReason });
        }

        // GET: api/document/{id}/download
        [HttpGet("{id}/download")]
        public async Task<IActionResult> Download(Guid id)
        {
            try
            {
                var (fileContent, contentType, fileName) = await _documentService.DownloadAsync(id);
                return File(fileContent, contentType, fileName);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
