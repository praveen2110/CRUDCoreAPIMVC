# Angular File Upload Application

A modern Angular application with file upload functionality that integrates with a .NET API backend.

## Features

- **File Upload**: Drag and drop or click to select files
- **Progress Tracking**: Real-time upload progress with visual progress bar
- **File Management**: View uploaded files with details (name, size, date)
- **Delete Files**: Remove uploaded files from the server
- **Responsive Design**: Works on desktop and mobile devices
- **Modern UI**: Beautiful gradient design with smooth animations

## Prerequisites

- Node.js (v14 or higher)
- Angular CLI (v13 or higher)
- .NET API backend (see API Requirements below)

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```

## Configuration

### API Endpoint Configuration

Update the API URL in `src/app/file-upload.service.ts`:

```typescript
private apiUrl = 'https://your-dotnet-api-url.com/api'; // Replace with your actual .NET API URL
```

### .NET API Requirements

Your .NET API should have the following endpoints:

#### 1. File Upload Endpoint
- **URL**: `POST /api/upload`
- **Content-Type**: `multipart/form-data`
- **Request Body**: FormData with file
- **Response**:
```json
{
  "success": true,
  "message": "File uploaded successfully",
  "filePath": "uploads/filename.ext",
  "fileName": "filename.ext",
  "fileSize": 1024
}
```

#### 2. Get Files Endpoint
- **URL**: `GET /api/files`
- **Response**:
```json
[
  {
    "id": "file-id",
    "fileName": "filename.ext",
    "fileSize": 1024,
    "uploadDate": "2024-01-01T00:00:00Z"
  }
]
```

#### 3. Delete File Endpoint
- **URL**: `DELETE /api/files/{fileId}`
- **Response**:
```json
{
  "success": true,
  "message": "File deleted successfully"
}
```

### CORS Configuration

Ensure your .NET API allows CORS for the Angular app:

```csharp
// In your .NET API Startup.cs or Program.cs
services.AddCors(options =>
{
    options.AddPolicy("AllowAngularApp", builder =>
    {
        builder.WithOrigins("http://localhost:4200")
               .AllowAnyHeader()
               .AllowAnyMethod();
    });
});
```

## Running the Application

1. Start the development server:
   ```bash
   ng serve
   ```

2. Open your browser and navigate to `http://localhost:4200`

3. The application will load with the file upload interface

## Usage

1. **Upload a File**:
   - Click "Choose File" or drag and drop a file
   - Click "Upload File" to start the upload
   - Watch the progress bar for upload status

2. **View Uploaded Files**:
   - Uploaded files appear in the "Uploaded Files" section
   - Each file shows name, size, and upload date

3. **Delete Files**:
   - Click the delete button (🗑️) next to any file
   - Confirm deletion in the popup dialog

## Project Structure

```
src/app/
├── file-upload/
│   ├── file-upload.component.ts      # Main component logic
│   ├── file-upload.component.html    # Component template
│   └── file-upload.component.css     # Component styles
├── file-upload.service.ts            # API service
├── app.component.ts                  # Root component
├── app.component.html                # Root template
├── app.component.css                 # Root styles
└── app.module.ts                     # App module configuration
```

## Technologies Used

- **Angular 13**: Frontend framework
- **TypeScript**: Programming language
- **RxJS**: Reactive programming
- **Angular HttpClient**: HTTP client for API calls
- **CSS3**: Modern styling with gradients and animations

## Development

### Adding New Features

1. Create new components using Angular CLI:
   ```bash
   ng generate component component-name
   ```

2. Add services for API calls:
   ```bash
   ng generate service service-name
   ```

### Building for Production

```bash
ng build --prod
```

The build artifacts will be stored in the `dist/` directory.

## Troubleshooting

### Common Issues

1. **CORS Errors**: Ensure your .NET API has CORS configured properly
2. **API Connection Issues**: Verify the API URL in the service file
3. **File Upload Fails**: Check file size limits and supported file types

### Debug Mode

Enable debug logging by adding console.log statements in the service methods.

## License

This project is licensed under the MIT License.