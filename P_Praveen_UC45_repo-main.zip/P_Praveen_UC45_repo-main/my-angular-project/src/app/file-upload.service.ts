import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpEventType, HttpProgressEvent, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export interface UploadProgress {
  loaded: number;
  total: number;
  percentage: number;
}

export interface UploadResponse {
  success: boolean;
  message: string;
  filePath?: string;
  fileName?: string;
  fileSize?: number;
}

@Injectable({
  providedIn: 'root'
})
export class FileUploadService {
  private apiUrl = 'https://localhost:7127/api/Document'; // Replace with your actual .NET API URL

  constructor(private http: HttpClient) { }

uploadFile(file: File, notificationEmail: string, uploadedBy: string): Observable<UploadResponse> {
  const formData = new FormData();
  formData.append('File', file); // Match property name in backend
  formData.append('NotificationEmail', notificationEmail);
  formData.append('UploadedBy', uploadedBy);

  return this.http.post<UploadResponse>(`${this.apiUrl}/upload`, formData, {
    reportProgress: true,
    observe: 'response'
  }).pipe(
    map((response: HttpResponse<UploadResponse>) => response.body!)
  );
}
uploadFileWithProgress(file: File, notificationEmail: string, uploadedBy: string): Observable<UploadProgress | UploadResponse> {
  const formData = new FormData();
  formData.append('File', file);
  formData.append('NotificationEmail', notificationEmail);
  formData.append('UploadedBy', uploadedBy);

  return this.http.post(`${this.apiUrl}/upload`, formData, {
    reportProgress: true,
    observe: 'events'
  }).pipe(
    map((event: HttpEvent<any>) => {
      switch (event.type) {
        case HttpEventType.UploadProgress:
          const progress: UploadProgress = {
            loaded: event.loaded,
            total: event.total || 0,
            percentage: Math.round(100 * event.loaded / (event.total || 1))
          };
          return progress;
        case HttpEventType.Response:
          return event.body as UploadResponse;
        default:
          return {} as UploadResponse;
      }
    })
  );
}

  // Method to get upload history or file list
  getUploadedFiles(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/files`);
  }

  // Method to delete uploaded file
  deleteFile(fileId: string): Observable<{ success: boolean; message: string }> {
    return this.http.delete<{ success: boolean; message: string }>(`${this.apiUrl}/files/${fileId}`);
  }
}
