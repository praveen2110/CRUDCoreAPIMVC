import { Component, OnInit } from '@angular/core';
import { FileUploadService, UploadProgress, UploadResponse } from '../file-upload.service';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {
selectedFile: File | null = null;
  uploadProgress: number = 0;
  isUploading: boolean = false;
  uploadMessage: string = '';
  uploadSuccess: boolean = false;
  uploadedFiles: any[] = [];
  notificationEmail: string = 'test@gmail.com'; // <-- Add this
  uploadedBy: string = 'test';        // <-- Add this

  constructor(private fileUploadService: FileUploadService) { }

  ngOnInit(): void {
    this.loadUploadedFiles();
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      this.resetUploadState();
    }
  }

  onUpload(): void {
    if (!this.selectedFile) {
      this.uploadMessage = 'Please select a file to upload.';
      return;
    }
    if (!this.notificationEmail || !this.uploadedBy) {
      this.uploadMessage = 'Please enter Notification Email and Uploaded By.';
      return;
    }

    this.isUploading = true;
    this.uploadProgress = 0;
    this.uploadMessage = '';

    this.fileUploadService.uploadFileWithProgress(
      this.selectedFile,
      this.notificationEmail,
      this.uploadedBy
    ).subscribe({
      next: (response) => {
        if ('percentage' in response) {
          // This is a progress update
          this.uploadProgress = response.percentage;
        } else {
          // This is the final response
          this.isUploading = false;
          this.uploadSuccess = response.success;
          this.uploadMessage = response.message;

          if (response.success) {
            this.selectedFile = null;
            this.notificationEmail = '';
            this.uploadedBy = '';
            this.loadUploadedFiles(); // Refresh the file list
          }
        }
      },
      error: (error) => {
        this.isUploading = false;
        this.uploadSuccess = false;
        this.uploadMessage = 'Upload failed: ' + (error.error?.message || error.message);
        console.error('Upload error:', error);
      }
    });
  }

  onDeleteFile(fileId: string): void {
    if (confirm('Are you sure you want to delete this file?')) {
      this.fileUploadService.deleteFile(fileId).subscribe({
        next: (response) => {
          if (response.success) {
            this.loadUploadedFiles(); // Refresh the file list
            this.uploadMessage = 'File deleted successfully.';
          } else {
            this.uploadMessage = 'Failed to delete file: ' + response.message;
          }
        },
        error: (error) => {
          this.uploadMessage = 'Delete failed: ' + (error.error?.message || error.message);
        }
      });
    }
  }

  private loadUploadedFiles(): void {
    this.fileUploadService.getUploadedFiles().subscribe({
      next: (files) => {
        this.uploadedFiles = files;
      },
      error: (error) => {
        console.error('Error loading files:', error);
      }
    });
  }

  private resetUploadState(): void {
    this.uploadProgress = 0;
    this.uploadMessage = '';
    this.uploadSuccess = false;
  }

  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }
}
